package com.example.logoactivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;

public class LogoActivity extends Activity {
    
    protected  void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.intro_activity); // xml, java 연결
        Handler handler = new Handler();

        int a=0;

        if(a==0) {
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                    startActivity(intent);
                    finish();
                }
            }, 2000);
        }
        else{
            handler.postDelayed(new Runnable() {
                @Override
                public void run() {
                    Intent intent = new Intent(getApplicationContext(), UserRegisterActivity.class);
                    startActivity(intent);
                    finish();
                }
            }, 2000);
        }

    }

    /*protected void onPause(){
        super.onPause();
        finish();
    }*/
    
}
