package com.example.logoactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        // 가게 등록 버튼 클릭시 액티비티 전환환
       Button registerStore_btn=(Button) findViewById(R.id.registerStore_btn);
        registerStore_btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Intent intent=new Intent(getApplicationContext(),RegisterStoreActivity.class);
                startActivity(intent);
            }
        });







    }
}