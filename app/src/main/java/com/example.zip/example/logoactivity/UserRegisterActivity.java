package com.example.logoactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class UserRegisterActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_register);
    }


}