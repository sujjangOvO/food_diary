package com.example.logoactivity;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.Toast;

public class RegisterStoreActivity extends AppCompatActivity {

    EditText Storename;
    String storename;
    EditText StorePostion;
    String position;
    EditText visitNum;
    int visitN;

    Spinner spinner;

    String resultType;  // spinner 값 받을 문자열, 익명클래스 내부에서는 onCreate의 멤버변수에 접근 할 수 없으므로 class의 멤버변수로.


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_store);


        RadioGroup waiting=(RadioGroup)findViewById(R.id.radioGroup); // 라디오 그룹 객체
        RadioGroup grade=(RadioGroup)findViewById(R.id.point);


        visitNum=(EditText)findViewById(R.id.visitNum);
        Storename=(EditText)findViewById(R.id.storename);
        StorePostion=(EditText)findViewById(R.id.position); // EditText 객체


       // storename=Storename.getText().toString(); // 가게 이름
       // position=StorePostion.getText().toString(); // 가게 위치



        spinner=findViewById(R.id.Mealtype); // spinner 객체

        ArrayAdapter type=ArrayAdapter.createFromResource(this,R.array.type,
                android.R.layout.simple_spinner_dropdown_item);
        type.setDropDownViewResource(android.R.layout.simple_dropdown_item_1line);

        spinner.setAdapter(type); // adapter 연결


        // 밥집종류 스피너 이벤트리스너
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                resultType=spinner.getSelectedItem().toString();
            } //이 오버라이드 메소드에서 position은 몇번째 값이 클릭됬는지 알 수 있습니다.
            //getItemAtPosition(position)를 통해서 해당 값을 받아올수있습니다.

            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });


        // 취소버튼클릭
        Button back_btn=(Button) findViewById(R.id.back_btn);
        back_btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){
                Toast.makeText(getApplicationContext(),"등록취소",Toast.LENGTH_LONG).show();
                Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                startActivity(intent);
            }
        });



        // 확인버튼클릭
        Button check_btn=(Button) findViewById(R.id.check_btn);
        check_btn.setOnClickListener(new View.OnClickListener(){
            public void onClick(View view){

                // 방문횟수
               try {
                   String str = visitNum.getText().toString().trim();
                   visitN=Integer.parseInt(str);
                   Toast.makeText(getApplicationContext(),"visitNumber= "+visitN,1).show();

               }catch (NumberFormatException e){ // 숫자 이외의 다른 값이 입력되면
                   Toast.makeText(getApplicationContext(),"숫자만 입력하세요.",1).show();
               }

                // Waiting 유,무 (O,X)
                String Resultwait;
                if(waiting.equals(null))  Toast.makeText(getApplicationContext(), "정보를 등록하세요.",
                        Toast.LENGTH_LONG).show();
                int id=waiting.getCheckedRadioButtonId(); // 선택된 RadioButton의 id값
                RadioButton waitCheck=(RadioButton)findViewById(id);


                // 평점 (1,2,3)
                String Resultpoint;
                if(grade.equals(null)) Toast.makeText(getApplicationContext(), "정보를 등록하세요.",
                        Toast.LENGTH_LONG).show();
                int point=grade.getCheckedRadioButtonId();
                RadioButton pointCheck=(RadioButton)findViewById(point);


                /*
                if(Storename.equals(null)||StorePostion.equals(null)){ // 다해줬짜나.......!!!!

                    Toast.makeText(getApplicationContext(), "정보를 등록하세요.",
                            Toast.LENGTH_LONG).show();

                } */


                if((Storename.getText().toString().equals("")|| Storename.getText()==null) // 왜자꾸null이뜰까요??
                        || (StorePostion.getText().toString().equals("")|| StorePostion.getText()==null) ){

                    Toast.makeText(getApplicationContext(), "정보를 등록하세요.",
                            Toast.LENGTH_LONG).show();

                }

                else{
                    storename=Storename.getText().toString(); // 가게 이름
                    position=StorePostion.getText().toString(); // 가게 위치
                    Resultwait=waitCheck.getText().toString(); // 웨이팅 유무 (O,X)
                    Resultpoint=pointCheck.getText().toString(); // 평점 (1,2,3)
                   // resultType  // 스피너 값
                    // visitN // 방문횟수

                    Toast.makeText(getApplicationContext(), "가게 정보가 등록되었습니다."+storename+position+resultType,
                            Toast.LENGTH_LONG).show();

                    Intent intent=new Intent(getApplicationContext(),MainActivity.class);
                    startActivity(intent);
                }



            }
        });



    } // end onCreate


} // end main